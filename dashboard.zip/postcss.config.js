module.exports = {
  plugins: [require('postcss-rtl'), require('autoprefixer')],
}
