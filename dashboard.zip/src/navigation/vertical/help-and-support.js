export default [
  {
    header: 'Help & Support',
  },
  {
    title: 'Tickets',
    icon: 'InboxIcon',
  },
  {
    title: 'Chat',
    icon: 'MessageCircleIcon',
  },
]
