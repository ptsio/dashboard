export default [
  {
    header: 'Email & Newsletter',
  },
  {
    title: 'Send Mail',
    icon: 'SendIcon',
  },
]
